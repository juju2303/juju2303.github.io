import sys, json, random
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QColor
from Creation_Onglets import Onglets
from Creation_Camembert import Camembert
from Creation_Legendes import Legendes
from Creation_Boutons import Boutons

with open("gros_fichiers.json", "r", encoding="utf-8") as f:
    fichiers = json.load(f)

couleurs = [QColor(random.randint(0,255), random.randint(0,255), random.randint(0,255)) for _ in fichiers]

def creer_script():
    with open("suppression.ps1", "w", encoding="utf-8") as f:
        f.write("Write-Output 'Suppression fichiers'\n")
        for page in pages:
            etats = page.recupere_etats_case_a_cocher()
            for i, etat in enumerate(etats):
                if etat:
                    chemin = fichiers[page.start+i][0]
                    f.write(f'Remove-Item -Path "{chemin}" -Force\n')

app = QApplication(sys.argv)
fenetre = Onglets()

fenetre.add_onglet("Camembert", Camembert(fichiers, couleurs).dessine_camembert())

pages = []
for i in range(0, len(fichiers), 25):
    leg = Legendes(fichiers, couleurs, i)
    pages.append(leg)
    fenetre.add_onglet(f"Légende {i//25+1}", leg.dessine_legendes())

fenetre.add_onglet("IHM", Boutons(sys.argv[1], creer_script).dessine_boutons())

fenetre.show()
sys.exit(app.exec_())
