import sys
from PyQt5.QtWidgets import QApplication, QFileDialog
from pathlib import Path

app = QApplication(sys.argv)

repertoire = QFileDialog.getExistingDirectory(
    None,
    "Sélectionnez le répertoire de base",
    str(Path.home())
)

if repertoire:
    print(repertoire)
