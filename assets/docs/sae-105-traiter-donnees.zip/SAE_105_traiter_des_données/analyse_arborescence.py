from pathlib import Path
import json
import sys

repertoire_base = Path(sys.argv[1])

fichiers = []
for f in repertoire_base.rglob("*"):
    if f.is_file():
        fichiers.append([str(f.resolve()), f.stat().st_size])

fichiers.sort(key=lambda x: x[1], reverse=True)
fichiers = fichiers[:100]

with open("gros_fichiers.json", "w", encoding="utf-8") as f:
    json.dump(fichiers, f, indent=2)
