from PyQt5.QtWidgets import QWidget, QTabWidget, QVBoxLayout, QMainWindow

class Onglets(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Analyse des gros fichiers")
        self.setGeometry(200, 100, 1000, 700)

        self.onglets = QTabWidget()
        self.setCentralWidget(self.onglets)

    def add_onglet(self, titre, widget):
        page = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(widget)
        page.setLayout(layout)
        self.onglets.addTab(page, titre)
