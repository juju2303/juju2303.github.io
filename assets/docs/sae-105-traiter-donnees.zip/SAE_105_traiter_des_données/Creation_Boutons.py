from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLineEdit
from PyQt5.QtCore import Qt

class Boutons:
    def __init__(self, repertoire, callback):
        self.repertoire = repertoire
        self.callback = callback

    def dessine_boutons(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignTop)

        btn = QPushButton("Créer le script PowerShell")
        btn.clicked.connect(self.callback)
        layout.addWidget(btn, alignment=Qt.AlignHCenter)

        txt = QLineEdit(self.repertoire)
        layout.addWidget(txt)

        return widget
