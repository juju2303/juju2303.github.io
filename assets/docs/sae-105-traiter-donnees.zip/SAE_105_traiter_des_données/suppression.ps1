Write-Output 'Suppression fichiers'
