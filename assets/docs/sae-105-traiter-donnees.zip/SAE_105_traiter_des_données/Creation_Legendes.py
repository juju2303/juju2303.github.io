from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QCheckBox
from PyQt5.QtCore import Qt

class Legendes:
    def __init__(self, fichiers, couleurs, start):
        self.fichiers = fichiers
        self.couleurs = couleurs
        self.start = start
        self.stop = min(len(fichiers), start + 25)
        self.cases = []

    def dessine_legendes(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)

        for i in range(self.start, self.stop):
            case = QCheckBox()
            self.cases.append(case)

            couleur = self.couleurs[i].name()
            carre = QWidget()
            carre.setFixedSize(15, 15)
            carre.setStyleSheet(f"background-color:{couleur}")

            chemin, taille = self.fichiers[i]
            label = QLabel(f"{chemin} (<font color='red'>{taille//1048576} MiB</font>)")
            label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

            ligne = QHBoxLayout()
            ligne.setAlignment(Qt.AlignLeft)
            ligne.addWidget(case)
            ligne.addWidget(carre)
            ligne.addWidget(label)
            ligne.addStretch()  # 👈 TRÈS IMPORTANT

            cont = QWidget()
            cont.setLayout(ligne)
            layout.addWidget(cont)

        return widget

    def recupere_etats_case_a_cocher(self):
        return [c.isChecked() for c in self.cases]
