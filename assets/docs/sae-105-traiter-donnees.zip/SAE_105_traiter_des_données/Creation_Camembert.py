from PyQt5.QtChart import QChart, QChartView, QPieSeries
from PyQt5.QtGui import QFont

class Camembert:
    def __init__(self, fichiers, couleurs):
        self.fichiers = fichiers
        self.couleurs = couleurs

    def dessine_camembert(self):
        series = QPieSeries()
        total = sum(f[1] for f in self.fichiers)

        for i, (chemin, taille) in enumerate(self.fichiers):
            slice_ = series.append(f"{taille//1048576} MiB", taille / total * 100)
            slice_.setBrush(self.couleurs[i])

        chart = QChart()
        chart.addSeries(series)
        chart.setTitle("Répartition des tailles")
        chart.legend().hide()

        return QChartView(chart)
