$rep = python3 selection_repertoire.py

if (-not $rep) {
    Write-Host "Aucun répertoire sélectionné"
    exit
}

python3 analyse_arborescence.py "$rep"
python3 affichage_resultats.py "$rep"
